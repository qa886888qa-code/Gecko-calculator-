# Gecko Calculator Android project

Native Android Studio starter project based on the supplied reference images.

## Included
- Dark/green calculator interface
- Basic arithmetic and a scientific keypad (sin/cos/tan/log/ln/square root/power)
- Unit converter (length, mass, temperature, volume)
- Loan EMI calculator
- BMI calculator
- Calculation history
- Basic y=x² graph preview
- AdMob banner and interstitial integration using the AdMob IDs visible in the screenshots

## Build APK
1. Open this folder in Android Studio (recent stable version).
2. Let Gradle sync and install Android SDK Platform 35 if prompted.
3. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will show the output APK path.

## Important before publishing
- The currency rates are demo estimates, not live market rates. Connect a trusted exchange-rate API before release.
- AdMob IDs are taken from the provided screenshots. Confirm they belong to your account and that the app is registered in AdMob.
- New ad units can take time to serve. Use Google's test ad IDs during development, follow AdMob policies, and never click your own live ads.
- The interstitial is only considered after every fifth completed calculation; review ad frequency and policies before release.
- This project source has not been built or tested on a local Android SDK in this environment. An APK is not included because a real Android build requires Android SDK/Gradle execution.
