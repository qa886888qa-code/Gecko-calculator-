package com.geckocalculator.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import com.google.android.gms.ads.*;
import com.google.android.gms.ads.interstitial.*;
import java.text.DecimalFormat;
import java.util.*;

public class MainActivity extends Activity {
    int bg=Color.rgb(8,17,22), panel=Color.rgb(20,34,42), key=Color.rgb(36,53,63), green=Color.rgb(57,231,95), white=Color.WHITE;
    LinearLayout root, content, nav;
    TextView display, result, modeLabel;
    String expr="", mode="Basic";
    ArrayList<String> history=new ArrayList<>();
    InterstitialAd interstitial;
    boolean dark=true;
    @Override public void onCreate(Bundle b){super.onCreate(b); MobileAds.initialize(this, s->{}); build(); loadInterstitial();}
    void loadInterstitial(){ AdRequest r=new AdRequest.Builder().build(); InterstitialAd.load(this,"ca-app-pub-9371973914123866/9175507151",r,new InterstitialAdLoadCallback(){
        @Override public void onAdLoaded(InterstitialAd ad){interstitial=ad;}
        @Override public void onAdFailedToLoad(LoadAdError e){interstitial=null;}
    });}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);return t;}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    void build(){
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(16,10,16,6);root.setBackgroundColor(dark?bg:Color.rgb(245,248,246));setContentView(root);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(4,8,4,14);
        TextView logo=text("🦎",30,green);header.addView(logo,new LinearLayout.LayoutParams(48,48));
        TextView title=text("Gecko Calculator",22,green);title.setTypeface(null,Typeface.BOLD);title.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);header.addView(title,new LinearLayout.LayoutParams(0,48,1));
        TextView theme=text(dark?"☀":"☾",25,green);theme.setOnClickListener(v->{dark=!dark;build();});header.addView(theme,new LinearLayout.LayoutParams(48,48));root.addView(header);
        LinearLayout tabs=new LinearLayout(this);for(String m:new String[]{"Basic","Scientific","Graph","Convert","Currency","Loan","BMI","History"}){TextView t=text(m,12,mode.equals(m)?bg:(dark?white:Color.DKGRAY));t.setPadding(10,12,10,12);t.setBackground(shape(mode.equals(m)?green:key,24));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.setMargins(3,0,3,8);tabs.addView(t,p);t.setOnClickListener(v->{mode=m;build();});}
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);hsv.addView(tabs);root.addView(hsv);
        content=new LinearLayout(this);content.setOrientation(1);content.setPadding(0,6,0,6);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        if(mode.equals("Basic")||mode.equals("Scientific")) calculator();
        else if(mode.equals("Convert")) converter();
        else if(mode.equals("Currency")) currency();
        else if(mode.equals("Loan")) loan();
        else if(mode.equals("BMI")) bmi();
        else if(mode.equals("History")) historyView();
        else graphView();
        // AdMob banner at the bottom. The unit ID is the one shown in the user's screenshot.
        AdView ad=new AdView(this);ad.setAdSize(AdSize.BANNER);ad.setAdUnitId("ca-app-pub-9371973914123866/8812481769");
        root.addView(ad,new LinearLayout.LayoutParams(-1,-2));ad.loadAd(new AdRequest.Builder().build());
    }
    void calculator(){
        LinearLayout screen=new LinearLayout(this);screen.setOrientation(1);screen.setPadding(12,16,12,16);screen.setBackground(shape(panel,24));
        modeLabel=text(mode.equals("Basic")?"STANDARD CALCULATOR":"SCIENTIFIC CALCULATOR",12,green);modeLabel.setGravity(Gravity.LEFT);screen.addView(modeLabel);
        display=text(expr.isEmpty()?"0":expr,25,white);display.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);display.setMinHeight(65);screen.addView(display);
        result=text(" ",34,white);result.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);result.setMinHeight(55);screen.addView(result);content.addView(screen);
        String[][] rows= mode.equals("Basic")?new String[][]{{"C","(",")","%"},{"7","8","9","÷"},{"4","5","6","×"},{"1","2","3","−"},{"±","0",".","+"},{"⌫","sin","=","÷"}}:
        new String[][]{{"sin","cos","tan","√"},{"log","ln","π","^"},{"C","(",")","%"},{"7","8","9","÷"},{"4","5","6","×"},{"1","2","3","−"},{"0",".","⌫","+"},{"=","±","×","÷"}};
        for(String[] row:rows){LinearLayout line=new LinearLayout(this);for(String s:row){TextView b=text(s,20,(s.equals("=")||s.equals("C"))?bg:white);b.setTypeface(null,Typeface.BOLD);b.setBackground(shape(s.equals("=")?green:(s.equals("C")?green:key),60));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,0,1);p.height=0;p.weight=1;p.setMargins(4,4,4,4);line.addView(b,p);b.setOnClickListener(v->press(s));}content.addView(line,new LinearLayout.LayoutParams(-1,0,1));}
    }
    void press(String s){
        if(s.equals("C")){expr="";result.setText(" ");display.setText("0");return;}
        if(s.equals("⌫")){if(!expr.isEmpty())expr=expr.substring(0,expr.length()-1);display.setText(expr.isEmpty()?"0":expr);return;}
        if(s.equals("=")){try{double val=eval(expr);String out=new DecimalFormat("0.##########").format(val);result.setText(out);history.add((expr.isEmpty()?"0":expr)+" = "+out);if(interstitial!=null&&history.size()%5==0){interstitial.show(this,a->{loadInterstitial();});} }catch(Exception e){result.setText("Invalid expression");}return;}
        if(s.equals("±")){if(!expr.isEmpty())expr="-("+expr+")";}
        else if(s.equals("π"))expr+=String.valueOf(Math.PI);
        else if(Arrays.asList("sin","cos","tan","log","ln","√").contains(s)){try{double x=eval(expr);double v=s.equals("sin")?Math.sin(Math.toRadians(x)):s.equals("cos")?Math.cos(Math.toRadians(x)):s.equals("tan")?Math.tan(Math.toRadians(x)):s.equals("log")?Math.log10(x):s.equals("ln")?Math.log(x):Math.sqrt(x);result.setText(new DecimalFormat("0.##########").format(v));history.add(s+"("+expr+") = "+result.getText());}catch(Exception e){result.setText("Enter a valid number");}return;}
        else if(s.equals("%"))expr+="/100";
        else if(s.equals("×"))expr+="*";else if(s.equals("÷"))expr+="/";else if(s.equals("−"))expr+="-";else expr+=s;
        display.setText(expr.isEmpty()?"0":expr);
    }
    // Small expression parser supporting + - * / ^ parentheses and decimals.
    double eval(String s){if(s==null||s.trim().isEmpty())return 0;return new Parser(s.replace("×","*").replace("÷","/")).parse();}
    static class Parser{
        String s;int p=0;Parser(String s){this.s=s.replace(" ","");}
        double parse(){double v=add();if(p<s.length())throw new RuntimeException();return v;}
        double add(){double v=mul();while(p<s.length()&&(s.charAt(p)=='+'||s.charAt(p)=='-')){char o=s.charAt(p++);double n=mul();v=o=='+'?v+n:v-n;}return v;}
        double mul(){double v=pow();while(p<s.length()&&(s.charAt(p)=='*'||s.charAt(p)=='/')){char o=s.charAt(p++);double n=pow();v=o=='*'?v*n:v/n;}return v;}
        double pow(){double v=atom();if(p<s.length()&&s.charAt(p)=='^'){p++;v=Math.pow(v,pow());}return v;}
        double atom(){if(p<s.length()&&s.charAt(p)=='-'){p++;return -atom();}if(p<s.length()&&s.charAt(p)=='('){p++;double v=add();if(p>=s.length()||s.charAt(p++)!=')')throw new RuntimeException();return v;}int st=p;while(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'))p++;if(st==p)throw new RuntimeException();return Double.parseDouble(s.substring(st,p));}
    }
    void field(LinearLayout box,String label,String hint){TextView l=text(label,14,green);l.setGravity(Gravity.LEFT);box.addView(l);EditText e=new EditText(this);e.setSingleLine();e.setHint(hint);e.setTextColor(dark?white:Color.BLACK);e.setHintTextColor(Color.GRAY);e.setBackground(shape(panel,12));e.setPadding(12,8,12,8);box.addView(e);e.setTag(label);}
    void converter(){TextView h=text("Unit Converter",24,green);content.addView(h);EditText input=new EditText(this);input.setHint("Enter value");input.setInputType(8194);input.setTextColor(white);content.addView(input);Spinner from=spinner(new String[]{"Meter","Kilometer","Centimeter","Mile","Kilogram","Gram","Pound","Celsius","Fahrenheit","Liter","Milliliter"});Spinner to=spinner(new String[]{"Kilometer","Meter","Centimeter","Mile","Gram","Kilogram","Pound","Fahrenheit","Celsius","Milliliter","Liter"});content.addView(from);content.addView(to);Button go=button("Convert");TextView out=text("",25,white);content.addView(go);content.addView(out);go.setOnClickListener(v->{try{double x=Double.parseDouble(input.getText().toString());String a=from.getSelectedItem().toString(),b=to.getSelectedItem().toString();double base=unit(x,a),res=fromBase(base,b);out.setText(new DecimalFormat("0.########").format(res)+" "+b);}catch(Exception e){out.setText("Please enter a value");}});}
    double unit(double x,String u){switch(u){case "Kilometer":return x*1000;case "Centimeter":return x/100;case "Mile":return x*1609.344;case "Gram":return x/1000;case "Pound":return x*0.45359237;case "Celsius":return x+273.15;case "Fahrenheit":return (x-32)*5/9+273.15;case "Liter":return x;case "Milliliter":return x/1000;default:return x;}}
    double fromBase(double x,String u){switch(u){case "Kilometer":return x/1000;case "Centimeter":return x*100;case "Mile":return x/1609.344;case "Gram":return x*1000;case "Pound":return x/0.45359237;case "Celsius":return x-273.15;case "Fahrenheit":return (x-273.15)*9/5+32;case "Liter":return x;case "Milliliter":return x*1000;default:return x;}}
    Spinner spinner(String[] items){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);s.setAdapter(a);return s;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(bg);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));return b;}
    void currency(){content.addView(text("Currency Converter",24,green));EditText amount=new EditText(this);amount.setHint("Amount");amount.setInputType(8194);amount.setTextColor(white);content.addView(amount);Spinner from=spinner(new String[]{"USD","PKR","EUR","GBP","INR"}),to=spinner(new String[]{"PKR","USD","EUR","GBP","INR"});content.addView(from);content.addView(to);TextView note=text("Rates are sample estimates. Connect a live exchange-rate API before publishing.",12,Color.LTGRAY);content.addView(note);TextView out=text("",25,white);content.addView(button("Convert"));((Button)content.getChildAt(content.getChildCount()-1)).setOnClickListener(v->{try{double x=Double.parseDouble(amount.getText().toString());Map<String,Double> r=new HashMap<>();r.put("USD",1d);r.put("PKR",284.5);r.put("EUR",0.92);r.put("GBP",0.78);r.put("INR",83.1);out.setText(new DecimalFormat("0.00").format(x/r.get(from.getSelectedItem())*r.get(to.getSelectedItem()))+" "+to.getSelectedItem());}catch(Exception e){out.setText("Enter amount");}});content.addView(out);}
    void loan(){content.addView(text("Loan & EMI Calculator",24,green));EditText principal=edit("Loan amount"),rate=edit("Annual interest rate (%)"),years=edit("Years");content.addView(principal);content.addView(rate);content.addView(years);TextView out=text("",20,white);content.addView(button("Calculate EMI"));((Button)content.getChildAt(content.getChildCount()-1)).setOnClickListener(v->{try{double p=Double.parseDouble(principal.getText().toString()),r=Double.parseDouble(rate.getText().toString())/1200,n=Double.parseDouble(years.getText().toString())*12;double emi=r==0?p/n:p*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1);out.setText("Monthly payment: "+new DecimalFormat("#,##0.00").format(emi));}catch(Exception e){out.setText("Fill all fields correctly");}});content.addView(out);}
    EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setInputType(8194);e.setTextColor(white);e.setHintTextColor(Color.LTGRAY);e.setBackground(shape(panel,12));e.setPadding(12,8,12,8);return e;}
    void bmi(){content.addView(text("BMI Calculator",24,green));EditText kg=edit("Weight in kg"),cm=edit("Height in cm");content.addView(kg);content.addView(cm);TextView out=text("",22,white);content.addView(button("Calculate BMI"));((Button)content.getChildAt(content.getChildCount()-1)).setOnClickListener(v->{try{double w=Double.parseDouble(kg.getText().toString()),h=Double.parseDouble(cm.getText().toString())/100,b=w/(h*h);out.setText("BMI: "+new DecimalFormat("0.0").format(b)+"\n"+(b<18.5?"Below standard range":b<25?"Standard range":b<30?"Above standard range":"High range"));}catch(Exception e){out.setText("Enter weight and height");}});content.addView(out);}
    void historyView(){content.addView(text("History & Memory",24,green));if(history.isEmpty())content.addView(text("Your calculations will appear here.",16,white));for(int i=history.size()-1;i>=0;i--){TextView t=text(history.get(i),16,white);t.setGravity(Gravity.LEFT);t.setPadding(8,12,8,12);content.addView(t);}Button clear=button("Clear History");content.addView(clear);clear.setOnClickListener(v->{history.clear();build();});}
    void graphView(){content.addView(text("Graphing Calculator",24,green));content.addView(text("Basic graph preview: y = x²",16,white));Graph g=new Graph();content.addView(g,new LinearLayout.LayoutParams(-1,0,1));content.addView(text("For advanced equations, use the scientific mode for calculations.",13,Color.LTGRAY));}
    class Graph extends View{android.graphics.Paint p=new android.graphics.Paint(3);Graph(){super(MainActivity.this);}protected void onDraw(android.graphics.Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2,cy=h/2;p.setColor(Color.rgb(54,78,87));p.setStrokeWidth(1);for(int x=0;x<w;x+=40)c.drawLine(x,0,x,h,p);for(int y=0;y<h;y+=40)c.drawLine(0,y,w,y,p);p.setColor(white);p.setStrokeWidth(2);c.drawLine(0,cy,w,cy,p);c.drawLine(cx,0,cx,h,p);p.setColor(green);p.setStrokeWidth(4);float lastX=0,lastY=0;for(int x=0;x<w;x++){float xx=(x-cx)/30f, yy=xx*xx;float y=cy-yy*30;if(x>0&&y>=0&&y<=h)c.drawLine(lastX,lastY,x,y,p);lastX=x;lastY=y;}}}
}